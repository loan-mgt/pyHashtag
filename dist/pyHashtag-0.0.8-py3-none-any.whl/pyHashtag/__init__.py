from .hashtag import hashtag, update



if __name__ == '__main__':
 
    
    print( "[bold green][INFO][/bold green] Starting...")
     	
    assert("test" == hashtag("test"))
        
    assert("#US" == hashtag("#US",debug=True))
       

    
